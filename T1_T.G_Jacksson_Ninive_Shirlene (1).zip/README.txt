Trabalho de Teoria dos Grafos
Professor: Raimundo Cláudio Vasconcelos
Alunos(as): Jacksson Yuri, Nínive Helen, Shirlene Oliveira
Data: 15/12/2022

Arquivo README com explicações de como rodar o código e seu funcionamento

Linguagem  utilizada
O código do trabalho foi criado utilizando a linguagem Python.

Objetivo do trabalho
O trabalho tem como objetivo processar um grafo e responder questões explicadas nas 
etapas abaixo desse arquivo README,no topico 4 na parte hora de rodar o codigo.

Primeiros passos...

Etapa de dowlond do arquivo

1. Primeiro baixe o arquivo compactado, baixe na área de trabalho ou em outro local no seu computador de sua preferência.

2. Após baixar a pasta, extraía a pasta baixada.

Etapa de instalação de bibliotecas necessárias.

1. Rode o arquivo requirements.txt na sua maquina, pois pode ser que algumas bibliotecas utilizadas não estejam instaladas na sua maquina. 
Exemplo: biblioteca para gerar o gráfico matplotlib.

2. O arquivo requirements.txt tem a versões da biblioteca matplotlib e a getsizeof e time. que foram utilizadas para fazer o gráfico
calcular memoria consumida e tempo de execução.

3. Para rodar o arquivo requirements.txt. Se você estive no windows ou no linux, abra seu terminal do computador e abra a pasta extraída pelo seu terminal do sistema 
o CMD que é do windows ou o terminal que é o do linux.
apos abrir a pasta rode o comando pip install -r requirements.txt, esse comando vai instalar todas as dependências necessárias para rodar o codigos na IDE

OBS : Se voce estiver no linux é necessario instalar o pip antes de começar a digitar os comando de instalaçao no terminal
digite sudo apt-get install python3-pip python-dev para instalar o pip, caso esteja no linux, e após isso pode seguir os passos citados acima
para instalar as depedências.

Hora de rodar o código.

1.Apos fazer todas as etapas acima, abra sua pasta que você baixou e descompactou em alguma IDE que rode códigos python

2. Apos abrir, rode o arquivo chamada main.py 

Como o código funciona

1. Após fazer todas as etapas acima, chegou a hora de rodar o codigo. 

2. Após rodar o codigo, ele contém um menu onde voce pode escolher qual arquivo txt voce deseja rodar
esse arquivo possui os grafos a serem pocessados.

3. Após escolher o arquivo txt, aguarde ate a finalização do programa, ele mostrará toda as saídas.

4. O programa trás dois tipos de saídas.

As saidas via terminal que são:
Quantidade de memória em MB: 
Maior Grau:
Menor Grau:
Quantidade de componentes conexos:  
Tempo de execução busca em largura:
Gráfico com a comparação de grau maior com maior grau possivel

As saídas via txt que são:
a saida do txt é um arquivo chamado saida.txt. Esse arquivo possui a seguinte saida.
Quantidade de vertice.
Quantidade de aresta.
E grau de cada vertice seguindo o seguinte padrão (numero da vertice, grau da vertice)



