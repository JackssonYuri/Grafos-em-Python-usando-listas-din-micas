from sys import getsizeof #biblioteca para calcular tamanho da memoria utilizada
import time  #biblioteca para pegar o tempo de execução da função
import matplotlib.pyplot as plt #usada para criar o gráfico

#Classe para o grafo
class Grafo:

  #Inicialização do grafo
	def __init__(self, lista_aresta):
		self.lista_aresta = lista_aresta
		self.grafo = {}

  #Função para adicionar as arestas ao grafo em formato de lista
	def adiciona_aresta(self):
		for v1, v2 in self.lista_aresta:
			if (v1 in self.grafo):
				self.grafo[v1].append(v2)
			else:
				self.grafo[v1] = [v2]

			if (v2 in self.grafo):
				self.grafo[v2].append(v1)
			else:
				self.grafo[v2] = [v1]
        
  #Função para calcular o numero de aresta
	def numero_aresta(self):
		aresta = len(self.lista_aresta)
		return aresta

#Função para abri o arquivo e processar vertice
def abrir_arquivo(caminho):
  arq = open(caminho)
  lista = []
  for linha in list(arq)[1::]:
      vertice = linha.split()
      lista.append((vertice[0], vertice[1]))
    
  return lista

#Menu para escolher o arquivo
def caminho_arquivo():
  caminho = ''
  arq = 0
  print("Digite o arquivo que deseja rodar")
  print("1: Para arquivo (collaboration_graph.txt)")
  print("2: Para arquivo (as_graph.txt)")
  arq = int(input("Escolha uma opção: "))
  if(arq == 1):
    caminho = 'collaboration_graph.txt'
  elif(arq == 2):
    caminho = 'as_graph.txt'
  
  print("Arquivo escolhido: ", caminho)
  print("\n")
  return caminho

#Chamada da função do caminho do arquivo
caminho = caminho_arquivo()
abrir_arquivo(caminho)

#função para calcular o numero e vertice
def numero_vertice(grafo):
	vertice = len(grafo)
	return vertice

#Função para calcular o numero do grau
def numero_grau(grafo):
	grafo_int = {}
	for key, value in grafo.items():
		grafo_int[int(key)] = [int(item) for item in value]

	grau = dict(map(lambda i: (i[0], len(i[1])), grafo_int.items()))
	return grau
  
#Função para converter o grau em lista 
def numero_grau_converte(grau):
	grau = list(grau.items())
	return grau

#Função para imprimir o grafo
def imprimir_grafo(grafo):
	return grafo

#função para carregar o grafo aparti do caminho do arquivo
def carrega_grafo():
	lista = abrir_arquivo(caminho)
	grafo = Grafo(lista)
	grafo.adiciona_aresta()
	return grafo

#Chamada da função carrega grafo
grafo_criado = carrega_grafo()
#Chamada do arquivo txt
lista_grafo_arquivo = abrir_arquivo(caminho)

#chamada da função imprimir grafo
grafo_lista = imprimir_grafo(grafo_criado.grafo)
#Chamada da função calcula vertice
tamanho_vertice = numero_vertice(grafo_criado.grafo)

##print('\n')
## print("Numero de aresta =",grafo_criado.numero_aresta())

tamanho_aresta = grafo_criado.numero_aresta()
## print("arestas = ", aresta)

# Função que retorna o maior grau do grafo
def maior_grau(quantidade_grau):  
	maior_grau = quantidade_grau[max(quantidade_grau, key=quantidade_grau.get)]
	return maior_grau

# Função que retorna o menor grau do grafo
def menor_grau(quantidade_grau):  
	menor_grau = quantidade_grau[min(quantidade_grau, key=quantidade_grau.get)]
	return menor_grau

#chamada da função do numero de grau
numero_grau = numero_grau(grafo_criado.grafo)
quantidade_grau = numero_grau_converte(numero_grau)

a = imprimir_grafo(grafo_criado.grafo)
m = round(getsizeof(a) / 1024 / 1024, 2)  #em MB

#printar quantidade de memoria utiizada para o grafico
print('Quantidade de memória em MB: ')
print(m)

#printar o maior grau
menor = maior_grau(numero_grau)
print('Maior Grau:')
print(menor)

#Printar o menor grau
maior = menor_grau(numero_grau)
print('Menor Grau:')
print(maior)


#Função de busca e largura
def dfs(grafo, inicio, temp=[]):
    print("processando busca em profundidade. Aguarde!")
    q=[inicio]
    while q:
        v=q.pop(0)
        if v not in temp:
            temp=temp+[v]
            q=grafo[v]+q
    return temp
  
vertice_inicial = (next(iter(grafo_lista)))
dfs(grafo_lista, vertice_inicial)

#Função para verificar componentes conexos
def componentes_conexos(grafo):
    print("processando componentes conexos. Aguarde!")
    visitados = set()
    def dfs(v):
        vs = set([v])
        component=[]
        while vs:
            v = vs.pop()
            visitados.add(v)
            vs |= set(grafo[v]) - visitados
            component.append(v)
        return component
    ans =[]
    for v in grafo:
        if v not in visitados:
            d=dfs(v)
            ans.append(d)
            
    return ans

#Return dos componentes conexos
compo_conexos = componentes_conexos((grafo_criado.grafo))

#Função para calcular quantidade e componentes conexos
def quant_componentes_conexos(compo_conexos):
    quant_compo_conexos = (len(compo_conexos))
    return quant_compo_conexos

#chamada da função para mostra quantidade de componentes conexos
quant_compo_conexos = quant_componentes_conexos(compo_conexos)
print("Quantidade de componentes conexos: ", quant_compo_conexos)


#Função busca em largura
ini = time.time()
def busca_largura(grafo, inicial,visitado):
   print("processando busca em largura. Aguarde!")
   lista_inicial = [inicial]
   while len(lista_inicial)> 0:
      inicial = lista_inicial.pop()
      if inicial not in visitado:
          visitado.add(inicial)
          for lista_adjacente in grafo[inicial]:
              if lista_adjacente not in visitado:
                   lista_inicial.append(lista_adjacente)
fim = time.time()

tempo_execucao = fim - ini  ##retorna tempo de exeução em segundos
print('Tempo de execução busca em largura: ', tempo_execucao)

# Função que retorna o diâmetro da internet(usando BFS)
def saida_arquivo(tamanho_vertice, quantidade_grau, aresta):

	with open('saida.txt', 'w') as f:
		f.write('# n = {}\n'.format(tamanho_vertice))
		f.write('# m = {}\n'.format(tamanho_aresta))
		f.write('{}\n'.format(quantidade_grau))
	
#Chamada da função que gera o arquivo de saida 
saida_arquivo(tamanho_vertice, quantidade_grau, tamanho_aresta)


# Função que imprime o gráfico do estudo de caso 2, questão 1
def exibir_grafico(menor, maior, tamanho_vertice):
	plt.plot([1, 1], [menor, maior], marker='o')
	plt.plot([1.01, 1.01], [tamanho_vertice, 1.01], marker='o')
	plt.show()

#chamada da função que gera o grafico
exibir_grafico(menor, maior, tamanho_vertice)




